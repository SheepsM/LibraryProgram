
package library;


public class admin extends person{
    String jobtitle;

    public admin(String name, String contact) {
        super(name, contact);
    }
    public void setjobtitle(String jobtitle) {
        this.jobtitle = jobtitle;
    }

    public String getJobtitle() {
        return jobtitle;
    }
    
    
    
}
