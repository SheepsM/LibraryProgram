package library;

import java.util.*;
import java.io.IOException;
import javax.swing.JOptionPane;
import java.awt.Component;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

public class Library {

    public static boolean bruh = true;
    public static ArrayList<books> books = new ArrayList<>();
    public static ArrayList<String> borrowers = new ArrayList<>();
    public static File file = new File("X:\\My Documents/books.txt");

    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws IOException {

        while (bruh == true) {

            System.out.println("1: Add new books ");
            System.out.println("2: Delete books not done");
            System.out.println("3: Add borrowers");
            System.out.println("4: Delete borrowers not done ");
            System.out.println("5: view all books");
            System.out.println("6: Exit");

            int menuSelection = sc.nextInt();

            switch (menuSelection) {
                case (1):
                    addbook();
                    break;
                case (2):
                    deletebook();
                    break;
                case (3):
                    borrowers();
                    break;
                case (5):
                    view();
                    break;
                case (6):
                    Exit();
                    break;

            }

        }
    }

    public static void addbook() throws IOException {
        System.out.println("input book to be added");
        String newbook = sc.next();
        System.out.println("What is the authors name");
        String author = sc.next();
        String bookauth = (newbook + " written by " + author);

        Component frame;
        books x;
        BufferedWriter writer = new BufferedWriter(new FileWriter("X:\\My Documents/books.txt"));
        writer.write(bookauth);
        writer.close();
        frame = null;
        x = new books(newbook, author);
        books.add(x);
        System.out.println("book has been added");

        System.out.println(x);

    }

    public static void deletebook() throws FileNotFoundException, IOException {

        BufferedReader br = new BufferedReader(new FileReader(file));

        String st;
        System.out.println("list of books");
        while ((st = br.readLine()) != null) {

            System.out.println(st);
            System.out.println("what book would you like to delete");
            String booktodel = sc.next();
            
        }}

    public static void borrowers() throws IOException {
        int identify = 0;
        BufferedReader br = new BufferedReader(new FileReader(file));
        BufferedWriter writer = new BufferedWriter(new FileWriter("X:\\My Documents/borrowedbooks.txt"));
        String st;
        System.out.println("list of books");
        while ((st = br.readLine()) != null) {
            System.out.println(st);
            System.out.println("which book would you like to borrow?");
            String borrowedbook = sc.next();
            System.out.println("what is your name? ");
            String borrowname = sc.next();
            System.out.println("what is your address?");
            String address = sc.next();
            borrowed y = new borrowed(borrowedbook, borrowname, address);
            borrowers.add("borrowers name : " + borrowname + " borrowed book: " + borrowedbook + " borrowers address: " + address);
            Component frame = null;
            writer.write("borrowers name : " + borrowname + " borrowed book: " + borrowedbook + " borrowers address: " + address);

            writer.close();
            JOptionPane.showMessageDialog(frame, borrowedbook + borrowname + address);

        }
    }

    public static void view() throws IOException {

        BufferedReader br = new BufferedReader(new FileReader(file));

        String st;
        System.out.println("list of books");
        while ((st = br.readLine()) != null) {
            System.out.println(st);
        }
    }

    public static void Exit() {
        bruh = false;
    }
}
