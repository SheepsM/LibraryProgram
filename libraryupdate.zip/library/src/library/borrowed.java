package library;

public class borrowed {

    String borrowedbook;
    String borrowname;
    String adress;

    public borrowed(String borrowedbook, String borrowname, String adress) {
        this.borrowedbook = borrowedbook;
        this.borrowname = borrowname;
        this.adress = adress;
        
    }

    public void setBorrowname(String borrowname) {
        this.borrowname = borrowname;
    }
    public void setBorrowedbook(String borrowedbook) {
         this.borrowedbook = borrowedbook;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

    public String getBorrowedbook() {
        return borrowedbook;
    }

    public String getBorrowname() {
        return borrowname;
    }

    public String getAdress() {
        return adress;
    }
}
