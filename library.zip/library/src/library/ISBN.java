package library;

import java.util.*;

public class ISBN {

    public static boolean ISBNcheck(int[] ISBN) {
        boolean valid = false;
        int Count = 0;

        int CalculatedDigit = 0;

        while (Count < 13) {
            CalculatedDigit = CalculatedDigit + ISBN[Count];
            Count++;
            CalculatedDigit = CalculatedDigit + ISBN[Count] * 3;
            Count++;

        }
        while (CalculatedDigit >= 10) {
            CalculatedDigit = CalculatedDigit - 10;

        }
        CalculatedDigit = 10 - CalculatedDigit;
        if (CalculatedDigit == 10) {
            CalculatedDigit = 0;

        }
        if (CalculatedDigit == ISBN[13]) {
            valid = true;

        }

        return valid;

    }

}
