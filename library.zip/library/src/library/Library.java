package library;

import java.util.*;
import java.io.IOException;
import javax.swing.JOptionPane;
import java.awt.Component;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

public class Library {

    public static ArrayList<books> books = new ArrayList<>();
    public static ArrayList<String> borrowers = new ArrayList<>();
    public static File file = new File("X:\\My Documents/books.txt");

    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws IOException {

        System.out.println("1: Add new books ");
        System.out.println("2: Delete books");
        System.out.println("3: Add borrowers");
        System.out.println("4: Delete borrowers");
        System.out.println("5: view all books");

        int menuSelection = sc.nextInt();

        switch (menuSelection) {
            case (1):
                addbook();

            case (2):
                deletebook();
                break;
            case (3):
                borrowers();
                break;
            case (5):
                view();
                break;

        }

    }

    public static void addbook() throws IOException {
        System.out.println("input book to be added");
        String newbook = sc.next();
        System.out.println("What is the ISBN?");
        int[] userISBN = new int[14];
        for (int i = 0; i < 13; i++) {
            userISBN[i] = sc.nextInt();
        }

        if (ISBN.ISBNcheck(userISBN)) {
            BufferedWriter writer = new BufferedWriter(new FileWriter("X:\\My Documents/books.txt"));
            Component frame = null;
            books x = new books(newbook, userISBN);
            books.add(x);
            System.out.println("book has been added");
            writer.write(newbook);
            writer.close();
            JOptionPane.showMessageDialog(frame, newbook);
            System.out.println(x);

        } else {
            System.out.println("ISBN is invalid");

        }

    }

    public static void deletebook() throws FileNotFoundException, IOException {

        BufferedReader br = new BufferedReader(new FileReader(file));

        String st;
        System.out.println("lsit of books");
        while ((st = br.readLine()) != null) {
            System.out.println(st);
       
        

    }}

    public static void borrowers() {

    }

    public static void view() throws IOException {

        BufferedReader br = new BufferedReader(new FileReader(file));

        String st;
        System.out.println("list of books");
        while ((st = br.readLine()) != null) {
            System.out.println(st);
        }
    }
}
