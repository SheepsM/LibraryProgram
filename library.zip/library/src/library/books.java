package library;

public class books {

    String name;
    int[] ISBN;
    

    public books(String name, int[] ISBN) {
        this.name = name;
        this.ISBN = ISBN;
        
    }

    public String getName() {
        return name;
    }

    public int[] getISBN() {
        return ISBN;
    }

    

    public void setName(String name) {
        this.name = name;
    }

    public void setISBN(int ISBN[]) {
        this.ISBN = ISBN;
    }

   

}

