package library;



public class books {

    String name;
    String author;
    

    public books(String name, String author) {
        this.name = name;
        this.author = author;
        
    }

    public String getName() {
        return name;
    }

    public String getauthor() {
        return author;
    }

    

    public void setName(String name) {
        this.name = name;
    }

    public void setauthor(String author) {
        this.author = author;
    }

   

}



